import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutterapp/model/GlucoseRecord.dart';
import 'package:flutterapp/model/GlucoseReminders.dart';

// import 'package:flutter/services.dart';
import 'package:flutterapp/view/NavigationBar.dart';

// import 'package:flutterapp/view/CustomRadioButton.dart';
import './AppBar.dart';
import 'package:flutterapp/controller/ReminderMgr.dart';
import 'package:flutterapp/controller/UserMgr.dart';

import 'Drawer.dart';

void main() => runApp(
      MaterialApp(
        title: 'Diabetes App',
        home: DailySchedule(),
        theme: ThemeData(
          // Define the default brightness and colors.
          primaryColor: Colors.teal.shade800,
          backgroundColor: Colors.pink.shade100,

          // Define the default font family.
          fontFamily: 'Roboto',

          // Define the default TextTheme. Use this to specify the default
          // text styling for headlines, titles, bodies of text, and more.
          textTheme: TextTheme(
              headline3: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.black),
              headline4: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.teal.shade800),
              headline5: TextStyle(fontSize: 40, color: Colors.teal.shade800),
              headline6: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  color: Colors.black)),
        ),
      ),
    );

/// UI component for setting daily blood glucose reading reminders.
class DailySchedule extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CommonAppBar(title: 'Daily Schedule'),
      body: DailyScheduleBody(),
      bottomNavigationBar: NavigationBar(),
      endDrawer: CustomDrawer(),
      backgroundColor: Theme.of(context).canvasColor,
    );
  }
}

class DailyScheduleBar extends StatelessWidget implements PreferredSizeWidget {
  final Color green = Color.fromRGBO(0, 110, 96, 1);
  final Color pink = Color.fromRGBO(254, 179, 189, 1);

  @override
  Size get preferredSize => const Size.fromHeight(50);

  @override
  Widget build(BuildContext context) {
    final double height = MediaQuery.of(context).size.height;
    final double width = MediaQuery.of(context).size.width;
    final double appBarTextSize = height * 0.035;
    final double appBarIconSize = width * 0.07;

    return AppBar(
      backgroundColor: green,
      leading: GestureDetector(
        onTap: () {},
        child: IconButton(
          icon: Icon(
            Icons.arrow_back,
            size: appBarIconSize,
            color: pink,
          ),
          onPressed: () {},
        ),
      ),
      title: Center(
        child: Text(
          'Create Daily Schedule',
          style: TextStyle(
            fontSize: 20,
            color: Color.fromRGBO(254, 179, 189, 1),
          ),
        ),
      ),
      actions: <Widget>[
        IconButton(
          icon: new Image.asset('images/user_icon.jpeg'),
          iconSize: appBarIconSize,
          padding: EdgeInsets.only(right: 18.0),
          onPressed: () {},
        ),
      ],
    );
  }
}

class DailyScheduleBody extends StatefulWidget {
  @override
  createState() {
    return new DailyScheduleBodyState();
  }
}

class DailyScheduleBodyState extends State<DailyScheduleBody> {
  final double borderRadius = 10;
  final double margin = 5;
  final double padding = 5;
  final double iconSize = 56;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(child: MyCustomForm());
    throw UnimplementedError();
  }
}

class MyCustomForm extends StatefulWidget {
  @override
  MyCustomFormState createState() {
    return MyCustomFormState();
  }
}

// Define a corresponding State class.
// This class holds data related to the form.
class MyCustomFormState extends State<MyCustomForm> {
  // Create a global key that uniquely identifies the Form widget
  // and allows validation of the form.
  //
  // Note: This is a `GlobalKey<FormState>`,
  // not a GlobalKey<MyCustomFormState>.
  final _formKey = GlobalKey<FormState>();
  TimeOfDay _time = TimeOfDay.now();

  void _selectTime(BuildContext context) async {
    final TimeOfDay newTime = await showTimePicker(
      context: context,
      initialTime: _time,
    );
    if (newTime != null) {
      setState(() {
        _time = newTime;
      });
    }
  }

  Widget _buildReminder() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(
          padding: EdgeInsets.only(left: 10, bottom: 10, top: 10, right: 10),
          width: MediaQuery.of(context).size.width * 0.75,
          height: 60,
          decoration: BoxDecoration(
            color: Colors.white,
              border: Border.all(color: Theme.of(context).shadowColor),
              borderRadius: BorderRadius.circular(5.0)),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("${_time.format(context)}",
                  style: TextStyle(fontSize: 20)),
              IconButton(
                  icon: Icon(Icons.alarm_add_rounded),
                  onPressed: () => _selectTime(context))
            ],
          ),
        ),
        IconButton(
          icon: Icon(Icons.delete),
          onPressed: () {},
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    // Build a Form widget using the _formKey created above.

    return Form(
      key: _formKey,
      child: Container(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text(
              'Set Reminder',
              style: Theme.of(context).textTheme.display1,
            ),
            SizedBox(height: 5),
            _buildReminder(),
            SizedBox(height: 15),
            Text(
              '+ Add reminder',
              style: TextStyle(
                color: Colors.teal.shade800,
              ),
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.05,
            ),
            Center(
              child: ElevatedButton(
                child: Text("Create schedule",
                    style: Theme.of(context).textTheme.button),
                style: ElevatedButton.styleFrom(
                  shape: new RoundedRectangleBorder(
                    borderRadius: new BorderRadius.circular(30.0),
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                  primary: Theme.of(context).primaryColor,
                ),
                onPressed: () {
                  // Validate returns true if the form is valid, otherwise false.
                  if (_formKey.currentState.validate()) {
                    // If the form is valid, display a snackbar. In the real world,
                    // you'd often call a server or save the information in a database.

                    DateTime now = new DateTime.now();

                    ReminderMgr.addGlucoseReminder(DateTime(now.year, now.month,
                        now.day, _time.hour, _time.minute));

                    /*

                              Change to form data

                              GlucoseReminderMgr mgr =
                                  new GlucoseReminderMgr('nishasnr@gmail.com');
                              DateTime date = DateTime.parse("1969-07-20 20:18:04Z");
                              GlucoseReminder ent = GlucoseReminder(timings: date);
                              mgr.addReminder(ent);
                               */
                    return showDialog<void>(
                      context: context,
                      barrierDismissible: false, // user must tap button!
                      builder: (BuildContext context) {
                        // can add logic to store entry here
                        return AlertDialog(
                          //title: Text('AlertDialog Title'),
                          content: SingleChildScrollView(
                            child: ListBody(
                              children: <Widget>[
                                Text('Glucose reminder is set',
                                    style: TextStyle(
                                        fontSize: 30,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black)),
                                SizedBox(height: 20),
                                TextButton(
                                  child: Text('OK',
                                      style: TextStyle(
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black)),
                                  style: ButtonStyle(
                                      backgroundColor:
                                          MaterialStateProperty.all<Color>(
                                              Colors.green[500])),
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
